#ifndef HACKERS_H
#define HACKERS_H
#include <array>
#include <string>
#include "Player.h"
using namespace std;

class Hackers
{
    public:
    //default constructor
    Hacker();
    //parameterized contsructor
    Hacker(int l, string n);

    //getters
    string getHackerName();
    int getHackerLevel();
    int getCarmenProgress();
    //setters
    void setHackerName(string n);
    void setHackerLevel(int l);
    void setCarmenProgress(int p);

    //other member functions
    bool fightHacker(int stats[], Player P);

    private:
    int carmenProgress;
    string hackerName;
    int HackerLevel;
    string level1Hackers={};
    string level2Hackers={};
    string level3Hackers={};
    string level4Hackers={};
    string level5Hackers={};

};