#ifndef NPC_H
#define NPT_H
#include <string>
#include <array>

using namespace std;

class NPC
{
    public:
    //default constructor
    NPC();
    //parameterized constructor
    NPC(strig n, string p);

    //other memberfunctions
    bool isFriend();
    bool playNPC();

    private:
    int NPC count;
    string NPCname;
    string NPCnames={};
    string puzzleNames={};

};