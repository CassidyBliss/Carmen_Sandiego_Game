#include "BestBuy.h"
#include <string>
#include <iostream>
#include <array>

using namespace std;

//default constructor
BestBuy::BestBuy()
{
    storeNum = 1;
}

//parameterized constructor
BestBuy::BestBuy(int s)
{
    storeNum = s;
}

//getters
int BestBuy::getProdPrice(string p, int s) const
{
    int prodLoc = 0;
    //add lowercase helper function to this one
    for(int i = 0; i < 6; i++)
    {
        if(products[i] == p)
        {
            prodLoc = i;
        }
    }
    switch(s)
    {
        case 1 : return prodPrices1[prodLoc];
        break;

        case 2 : return prodPrices2[prodLoc];
        break;

        case 3 : return prodPrices3[prodLoc];
        break;

        case 4 : return prodPrices4[prodLoc];
        break;

        case 5 : return prodPrices5[prodLoc];
        break;
    }

    
}

//setters

//other member functions
void BestBuy::buyProduct(string p, int s, Player P)
{
    //adjust dogecoin and inventory for Player P
    // Use product name and store number to derive cost
    //cout statement/ reciept
    //do not complete transation without enough dogecoin
}

