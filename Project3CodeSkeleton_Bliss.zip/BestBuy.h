#ifndef BESTBUY_H
#define BESTBUY_H

#include <string>
#include <array>

using namespace std;

class BestBuy
{
    public:
    //default constructor
    BestBuy();

    //parameterized constructor
    BestBuy(int s);

    //getters
    int getProdPrice(string p, int s);

    //other member functions
    void buyProduct(string p, int s, Player P);

    private:

    int storeNum;
    string products[]= {"CUP","GPU","Power Supply Unit", "Computer Case","Internet Card", "Keyboard and Mouse","Premade Computer"};
    int prodPrices1[]= {10,20,5,15,5,10,100};

    //still need to adjust these:
    int prodPrices2[]= {10,20,5,15,5,10,100}; //some % higher
    int prodPrices3[]= {10,20,5,15,5,10,100}; //some % higher
    int prodPrices4[]= {10,20,5,15,5,10,100}; //some % higher
    int prodPrices5[]= {10,20,5,15,5,10,100}; //some % higher

};