#include "Hackers.h"
#include <iostream>
#include <string>
#include <array>

using namespace std;


//default contructor
Hacker::Hacker()
{
    hackerName = "";
    hackerLevel = 0;
}

//parameterized constructor
Hacker::Hacker(int l, string n)
{
    hackerLevel = l;
    hackerName = n;
}
//getters
string Hacker::getHackerName()
{
    return hackerName;
}

int Hacker::getHackerLevel()
{
    return hackerLevel;
}

int Hacker::getCarmenProgress()
{
    return carmenProgress;
}
//setters

void Hacker::setHackerName(string n)
{
    hackerName = n;
}

void setHackerLevel(int l)
{
    hackerLevel = l;
}

void setCarmenProgress(int p)
{
    carmenProgress = p;
}

//other memberfunctions
bool fightHacker(int stats[], Player p)
{
    //this will be quite a problem to solve later
    //use forumla given in instructions for whether a fight was won or lost
    //adjust player's stats accordingly
}