#include "NPC.h"
#include <string>
#include <array>
#include <iostream>

using namespace std;

//default constructor
NPC::NPC()
{

}
//parameterized constructor
NPC::NPC(string n)
{
    NPCname = N
}
//other member functions:
bool isFriend()
{
    bool isFriend = 0;
    return isFriend;
}

bool playNPC()
{
    bool Playcompleted = 0;
    return Playcompleted;
}