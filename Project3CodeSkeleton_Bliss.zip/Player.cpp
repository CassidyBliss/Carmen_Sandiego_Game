#include "Player.h"
#include <string>
#include <iostream>
#include <array>

using namespace std;

Player::Player()
{
    //set all default values:
    name = "";
    dogeCoin = 200;
    internetLevel = 1
    antivirus = 0;
    VPN = 1;
    frustrationLevel = 0;
    compMaintLevel = 0;
    compParts[6] = 1;
}

//parameterized constructor
Player::Player(string n, int d,int i, int a, int v, int f)
{
    name = n;
    dogeCoin = d;
    internetLevel = i;
    antivirus = a;
    VPN = v;
    frustrationLevel = f;
    comParts[6] = 1;
}

//getters
int Player::getDogeCoin() const
{
    return name;
}

int Player::getInternetLevel() const
{
    return internetLevel;
}

int Player::getAntivirus() const
{
    return antiVirus;
}

int Player::getVPN()const
{
    return VPN;
}

int Player::getFrustrationLevel() const
{
    return frustrationLevel;
}