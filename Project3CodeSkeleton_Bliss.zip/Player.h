#ifndef PLAYER_H
#define PLAYER_H
#include <string>
#include <array>

using namespace std;

class Player
{
    public:

    //default constructor
    Player();

    //parameterized constructor
    Player(string n, int d, int i, int a, int v, int f);

    //getters
    int getDogeCoin();
    int getInternetLevel();
    int getAntiVirus();
    int getVPN();
    int getFrustrationLevel();
    int getCompMaintLevel();
    int getNumCompPart(string p);
    int getStats();
    int getInventory();

    //setters
    int setDogeCoin(int d);
    int setInternetLevel(int i);
    int setAntiVirus(int a);
    int setFrustrationLevel(int f);
    int setCompMaintLevel(int c);
    int setNumCompPart(int n, string p);
    int setStats(int d, int i , int a, int v, int f, int c);

    //other member functions
    bool misfortunateEvent();
    
    private:

    int const maxFrustration = 100;
    string name;
    int dogeCoin;
    int internetLevel;
    int antiVirus;
    int VPN;
    int frustrationLevel;
    int compMaintLevel;
    int numCompParts[]={0,0,0,0,0,0,1};
    string compParts = {"CUP","GPU","Power Supply Unit", "Computer Case","Internet Card", "Keybpard and Mouse","Premade Computer"}; 
    int stats[]={dogecoin, internetLevel, antiVirus, VPN, frustrationLevel, compMaintLevel};
    string statNames[]= {"dogecoin", "internetLevel", "antiVirus", "VPN", "frustrationLevel", "compMaintLevel"};
};