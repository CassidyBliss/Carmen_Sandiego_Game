#include "Player.h"
#include <string>
#include <iostream>
#include <array>

using namespace std;

int main()
{
    //work in progress
    Player player1();
    Player player2("name", 200,1,1,1,0,0);
    cout << player1.getDogeCoin() << endl;
    cout << player2.getInternetLevel() << endl;
    cout << player1.getAntivirus() << endl;
    cout << player2.getVPN() << endl;
    cout << player1.getFrustrationLevel() << endl;
    cout << player2.getComMaintLevel() << endl;
    player1.getInventory() << endl;
    player2.getStats() <<endl;

    //more to come
    return 0;
}